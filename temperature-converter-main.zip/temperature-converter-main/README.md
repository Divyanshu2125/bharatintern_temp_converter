# temperature-converter
bharat  intern
It converts celsius to fahrenheit 
we have to give inputs 
IT is taken as celsius and it is converted to fahrenheit by using math formula
Temperature in degrees Fahrenheit (°F) = (Temperature in degrees Celsius (°C) * 9/5) + 32
![temp3](https://github.com/Sajja-Jayasaikumar/temperature-converter/assets/135859891/57937117-dee9-456e-a868-cc62d2955d35)

